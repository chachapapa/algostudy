package class4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class wormholl {

	static class node {
		int to;
		int time;

		public node(int to, int time) {
			this.to = to;
			this.time = time;
		}

	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int t = sc.nextInt();

		for (int test = 1; test <= t; test++) {

			int n = sc.nextInt();
			int m = sc.nextInt();
			int w = sc.nextInt();

			List<List<node>> list = new ArrayList<>();

			for (int i = 0; i < n + 1; i++) {
				list.add(new ArrayList<>());
			}

			for (int i = 0; i < m; i++) {
				int start = sc.nextInt();
				int end = sc.nextInt();
				int time = sc.nextInt();
				list.get(start).add(new node(end, time));
				list.get(end).add(new node(start, time));
			}

			for (int i = 0; i < w; i++) {
				list.get(sc.nextInt()).add(new node(sc.nextInt(), -sc.nextInt()));
			}

			int[] dist = new int[n + 1];
			int INF = 987654321;

			for (int i = 0; i < n + 1; i++) {
				dist[n] = INF;
			}
			
			dist[1] = 0;


			for (int i = 1; i < n; i++) {

				for (int j = 1; j <= list.size(); j++) {
					for (node now : list.get(j)) {
						if (dist[now.to] > dist[j] + now.time) {
							dist[now.to] = dist[j] + now.time;
						}
					}
				}

			}

			
			for(int i = 1; i<list.size() ; i++) {
				for(node now : list.get(i)) {
					if(dist[now.to] > dist[i]+now.time) {
						System.out.println("YES");
						return;
					}
				}
			}
			System.out.println("NO");
		}

	}

}
