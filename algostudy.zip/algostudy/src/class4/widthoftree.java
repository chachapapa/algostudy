package class4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class widthoftree {
	
	static class node{
		int to;
		int length;
		
		
		public node(int to, int length) {
			this.to = to;
			this.length = length;
		}
		
		
	}
	static int n;
	static int start;
	static int end;
	static int length;
	static List<List<node>> list;
	
	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
		n = sc.nextInt();
		
		list = new ArrayList<>();
		
		for(int i = 0 ; i< n+1 ; i++) {
			list.add(new ArrayList<>());
		}
		
		for(int i = 0 ; i< n-1 ; i++) {
			start = sc.nextInt();
			end = sc.nextInt();
			length = sc.nextInt();
			
			list.get(start).add(new node(end, length));
			list.get(end).add(new node(start, length));
		}
		
	}
	
	static int max = 0;
	static boolean[] visited = new boolean[n+1];
	
	public static void dfs(int x int);
}
