package WnjnTmsk;

import java.util.Scanner;

public class yeonsanmaxmin {

	static int[] numbers;
	static int[] pm;
	static int max;
	static int min;

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();

		numbers = new int[n];

		for (int i = 0; i < n; i++) {
			numbers[i] = sc.nextInt();
		}

		pm = new int[4];

		for (int i = 0; i < 4; i++) {
			pm[i] = sc.nextInt();
		}
		
		
		
		max = -1000000000;
		min = 1000000000;
		
		
		yeonsan(0, numbers[0], pm[0] , pm[1] , pm[2] , pm[3]);
		
		System.out.println(max+"\n"+min);

	}

	public static void yeonsan(int idx, int result, int plus, int minus, int multiple, int divide) {

		if (plus > 0) {
			yeonsan(idx + 1, result + numbers[idx + 1], plus - 1, minus, multiple, divide);

		}

		if (minus > 0) {
			yeonsan(idx + 1, result - numbers[idx + 1], plus, minus - 1, multiple, divide);
		}

		if (multiple > 0) {
			yeonsan(idx + 1, result * numbers[idx + 1], plus, minus, multiple - 1, divide);
		}

		if (divide > 0) {
			yeonsan(idx + 1, result / numbers[idx + 1], plus, minus, multiple, divide-1);

		}
		
		if(plus == 0 && minus == 0 && multiple == 0 && divide == 0 ) {
			if(result < min) {
				min = result;
			}
			
			if(result > max) {
				max = result;
			}
		}
	}

}
