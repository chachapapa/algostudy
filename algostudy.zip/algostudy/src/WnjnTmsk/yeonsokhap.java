package WnjnTmsk;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class yeonsokhap {

	public static void main(String[] args) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		String str = br.readLine();
		StringTokenizer st = new StringTokenizer(str);

		// 100000이하
		int[] arr = new int[n];
		for (int i = 0; i < n; i++) {
			arr[i] = Integer.parseInt(st.nextToken());
			
		}

		// System.out.println(Arrays.toString(arr));
		

		int startsum = 0;
		int max = -1000;

		for (int i = 0; i < n; i++) {
//			System.out.println("시작 인덱스가"+ ""+ i+"일때");
			startsum += arr[i];
			
			if (max < startsum) {
				max = startsum;
			}
//			System.out.println(sum);
			if (startsum <= 0) {
//				System.out.println(sum);
				startsum = 0;
				//System.out.println("스타트 변경"+start);
			}
			
			
		}
		
		System.out.println(max);
		
		// 순서대로 다 더하다가 합이 음수가 나오면 모두 더한 값이 최대가 될수 없으므로
		// start를 그 다음값으로 옮겨줬는데
		// 모두 음수인 경우에는 start값이 인덱스 밖으로 벗어남.
		//
/*
		if (start >= n) {
			System.out.println(max);
		} else {

			int end = n - 1;
			int endsum = 0;
			for (int i = n - 1; i >= start; i--) {
//				System.out.println("시작 인덱스가"+ ""+ i+"일때");
				endsum += arr[i];
//				System.out.println(sum);
				if (endsum <= 0) {
//					System.out.println(sum);
					end = i - 1;
					endsum = 0;
//					System.out.println("스타트 변경"+start);
				}

			}

			for (int i = start; i <= end; i++) {
				sum += arr[i];
			}
			//"시작" + start + "끝" + end + " " +
			System.out.println( sum);
		}*/
		//반ㄹㅖ
//		30
//		2 -3 10 -6 -2 -4 -5 3 -9 3 8 -6 -6 4 6 -7 5 -7 3 4 10 0 -3 -6 6 -9 -7 -10 0 -2
		
//아 뭔 타노스도 아니고 반틈 날리니까 되냐고 ㅡㅡ
	}

}