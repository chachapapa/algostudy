package WnjnTmsk;

import java.util.Scanner;

public class AandB {

	static String a = "A";
	static String b = "B";
	static int res;

	public static void main(String[] args) {

		// 뒤에 a 추가
		// 뒤에 b 추가하고 뒤집기.

		// 한 문자열에서 다른 문자열로 변경이 가능한지???

		// 가능시 1
		// 불가능시 0

		Scanner sc = new Scanner(System.in);

		String x =sc.next();
		String y = sc.next();

		change(x, y);

		if (res > 0) {
			System.out.println(1);
		} else {
			System.out.println(0);
		}
	}

	public static void change(String x, String y) {
		if (x.length() < y.length()) {
			
			if (y.charAt(y.length() - 1) == 'A') {
				StringBuilder sb1 = new StringBuilder();
				sb1.append(y);
				String yy = sb1.deleteCharAt(sb1.length()-1).toString();
				//System.out.println("A빠짐"+yy);
				change(x, yy);
			}
			
			
			if (y.charAt(0) == 'B') {
				//System.out.println("왜 여기안걸려?");
				StringBuilder sb2 = new StringBuilder();
				sb2.append(y);
				String yyy = sb2.reverse().deleteCharAt(sb2.length()-1).toString();
				//System.out.println("뒤집고 B뺌"+yyy);
				change(x, yyy);
			}

			
		} else if (x.length() == y.length()) {
			//System.out.println("x는 "+x + "y는 "+y);
			if(x.equals(y)) {
			res++;
			}
		}

	}

}

/*
	public static void change(String x, String y) {
		if (x.length() < y.length()) {
			StringBuilder sb1 = new StringBuilder();
			sb1.append(x);
			change(sb1.append(a).toString(), y);
			
			
			StringBuilder sb2 = new StringBuilder();
			sb2.append(x);
			change(sb2.append(b).reverse().toString(), y);
		} else if (x.length() == y.length()) {
			if (x.equals(y)) {
				res++;
			}
		}

	}
	*/