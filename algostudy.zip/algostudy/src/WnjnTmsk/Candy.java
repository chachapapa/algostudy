package WnjnTmsk;

import java.util.Arrays;
import java.util.Scanner;

class Candy {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();

		String[][] box = new String[n + 2][n + 2];

		// 빨강C 파랑P 초록Z 노랑Y
		for (int x = 1; x < n + 1; x++) {
			String[] tmp = sc.next().split("");
			for (int y = 1; y < n + 1; y++) {
				box[x][y] = tmp[y - 1];
			}

		}
//		for (int x = 0; x < n + 2; x++) {
//			System.out.println(Arrays.toString(box[x]));
//		}

		int length = 0;
		int max = 0;

		int[] dx = { 0, 0, 1, -1 };
		int[] dy = { 1, -1, 0, 0 };

		for (int x = 1; x < n + 1; x++) {
			for (int y = 1; y < n + 1; y++) {
				for (int i = 0; i < 4; i++) {
					String tmp = box[x][y];
					if (box[x + dx[i]][y + dy[i]] != null) {
						
						box[x][y] = box[x + dx[i]][y + dy[i]];
						box[x + dx[i]][y + dy[i]] = tmp;

						
//						for (int xx = 0; xx < n + 2; xx++) {
//							System.out.println(Arrays.toString(box[xx]));
//						}
						
						
						
						for (int sero = 1; sero < n + 1; sero++) {

							
							for (int garo = 1; garo < n + 1; garo++) {
								int movev = sero;
								String color = box[sero][garo];
							
								length = 0;
								// System.out.println("시작 세로가로" + sero + garo + "부터");
								
								while (box[movev][garo] != null && box[movev][garo].equals(color)) {

									length++;
									movev++;
								}
								// System.out.println("세로" + movev + "가로" + garo + "까지" + length);
								
								if (length > max) {

									max = length;
								}
							}
							
						}
						for (int sero = 1; sero < n + 1; sero++) {

							for (int garo = 1; garo < n + 1; garo++) {
//							if (x == 16 && y == 11) {
//								System.out.println(garo);
//							}
								length = 0;
								int moveh = garo;
								String color = box[sero][garo];
								while (box[sero][moveh] != null && box[sero][moveh].equals(color)) {
									length++;
									moveh++;
								}
								if (length > max) {
//									System.out.println(
//											"시작지점 " + sero + garo + "에서 " + sero + moveh + "까지   현재까지 최대길이는?" + length);
									max = length;

								}

							}
						}

						tmp = box[x][y];
						box[x][y] = box[x + dx[i]][y + dy[i]];
						box[x + dx[i]][y + dy[i]] = tmp;
					}
					
				}
			}
		}

		System.out.println(max);
	}

}
