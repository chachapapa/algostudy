package WnjnTmsk;

import java.util.Scanner;

public class ElonMusk {

	static int[][] space;
	static int[] move = { -1, 0, 1 };
	static int n;
	static int m;
	static int min;

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		// 달까지 거리x
		n = sc.nextInt();

		// 달까지 너비y
		m = sc.nextInt();

		space = new int[n][m];

		for (int x = 0; x < n; x++) {
			for (int y = 0; y < m; y++) {

				space[x][y] = sc.nextInt();

			}
		}
		min = 100 * n;
		// System.out.println("min 초기값" + min);
		// 대각선 두방향, 직진 가능.
		// 한번갔던 방향으로 그다음에 또 가는건 불가능.

		// 세로는 계속 늘어남.
		// for(int start = 0 ; start<m ; start++) {
		// 움직일 수 있는 방향.

		for (int start = 0; start < m; start++) {
			booster(0, start, 0, 2);
		}

		System.out.println(min);
	}

	public static void booster(int x, int y, int cost, int prev) {

		cost += space[x][y];

		//System.out.println("이전 move값" + prev);
		//System.out.println("x" + x + "y" + y + "까지 cost" + cost);
		if (x == n - 1 && cost < min) {
//			System.out.println("저장!");
			min = cost;
		}

		if (x + 1 < n) {
			for (int i : move) {
				if (i != prev && y + i >= 0 && y + i < m) {
					booster(x + 1, y + i, cost, i);

				}
			}
		} else {
			//System.out.println("도착!!");
		}

	}
}
