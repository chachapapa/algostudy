package algostudy;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class nnmm2 {
	
	static int[] arr;
	static int n;
	static int m;
	static int[] res;
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		n = sc.nextInt();
		m = sc.nextInt();
		
		arr = new int[n];
		
		for(int i = 0 ; i<n ; i++) {
			arr[i] = i+1;
		}
		
		//결과 순열을 넣을 res 배열.

		res = new int[m];
		
		perm(0,0);
		
	}
	
	public static void perm(int idx, int visited) {
		//idx가 목표 길이와 같아진다면, 출력하고 함수 종료.
		if(idx == m) {
			StringBuilder sb = new StringBuilder();
			
			for(int i = 0 ; i < res.length ; i++) {
				sb.append(res[i]+" ");
			}
			System.out.println(sb);
			return;
		}
		
		//arr의 원소들을 하나씩 조회하면서 
		//visited..는 
		
		for(int i = 0 ; i< n ; i++) {
			
			
			res[idx] = arr[i];
			//visited나 1<<i의 자리값이 하나라도 1이면 1 반환.
			perm(idx+1,visited|(1<<i));
		}
	}
}
