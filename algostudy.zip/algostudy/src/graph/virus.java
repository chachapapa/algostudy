package graph;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class virus {

	static class spot{
		int node;
		int status;
		
		public spot(int node, int status) {
			this.node = node;
			this.status = status;
		}
		
	}
	
	static int[][] lab;
	static List<spot> list;
	static int[] dx = { 1, -1, 0, 0 };
	static int[] dy = { 0, 0, 1, -1 };

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int d = sc.nextInt();
		int w = sc.nextInt();
		int node = 1;
		for (int i = 0; i < d; i++) {
			for (int j = 0; j < w; j++) {

				lab[i][j] = sc.nextInt();

			}
		}
		
		
		
		for (int i = 0; i < d; i++) {
			System.out.println(Arrays.toString(lab[i]));
		}
		
		for(int i = 0 ; i < d ; i++) {
			for(int j = 0 ; j< w ; j++) {
				list.add(new spot(node++,lab[i][j]));
			}
		}
		
	}
	
	
	
	
	
}
