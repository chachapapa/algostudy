package graph;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class networkconnect {
	
	static class node{
		int from;
		int to;
		int cost;
		
		public node(int from, int to, int cost) {
			this.from = from;
			this.to = to;
			this.cost = cost;
		}

		@Override
		public String toString() {
			return "node [from=" + from + ", to=" + to + ", cost=" + cost + "]";
		}
	}
	
	static int n;
	static int m;
	static List<node> list;
	static int linecount;
	static int linenum;
	static int[] p;
	static int ans;

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		//노드 수
		n = sc.nextInt();
		
		//간선 수
		m = sc.nextInt();
		
		list = new ArrayList<>();
		
		
		for(int i = 0 ; i < m ; i++) {
			int start = sc.nextInt();
			int end = sc.nextInt();
			int cost = sc.nextInt();
			
			list.add(new node(start, end , cost));
		}
		
		Collections.sort(list, new Comparator<node>() {

			@Override
			public int compare(node o1, node o2) {
				return Integer.compare(o1.cost, o2.cost);
			}
		});
		
		
//		System.out.println(list.toString());
		
		
		linecount = 0 ;
		linenum = 0;
		
		p = new int[n+1];
		
		for(int i = 0 ; i < n+1 ; i++) {
			p[i] = i ;
		} 
		
		ans = 0;
		while(linenum < m) {
			
			
			//px는 출발 노드 대가리
			int px = findset(list.get(linenum).from);
			//py는 도착 노드 대가리
			int py = findset(list.get(linenum).to);
			
			// 두 대가리가 다르다면 유니온이 가능.
			if(px != py) {
				union(px, py);
				//라인을 선택했으니 카운트 올리기
				linecount++;
				//해당 라인의 가중치 더해주기
				ans += list.get(linenum).cost;
			}
			
//			System.out.println(Arrays.toString(p));
			
			//다음 간선 체크
			linenum++;
			
			//선택한 라인 수가 노드 갯수 -1 이라면 최소 스패닝 트리 완성.
			if(linecount == n-1) break;
		}
		System.out.println(ans);
	}
	
	
	public static int findset(int node) {
		
		if (node != p[node]) {
			p[node] = findset(p[node]);
		}
		return p[node];
		
	}
	
	public static void union(int x, int y) {
		p[y] = x;
	}

}
