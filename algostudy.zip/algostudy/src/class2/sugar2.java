package class2;


import java.util.Scanner;

public class sugar2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		//정확한 n 키로를 배달
		
		double n = sc.nextDouble();
		System.out.printf("%.0f",n);
		double x = 0 ;
		boolean can = true;
		double five = 5.0;
		double three = 3.0;
		while(true) {
			if(n < three*x) {
				can = false;
				System.out.println(-1);
				break;
			}
			
			if((n-three*x)%five != 0) {
				x++;
			}else {
				break;
			}
		}
		
		if(can) {
			System.out.println(n/five);
			System.out.println(n%five);
			System.out.println( );
			System.out.println(x);
			System.out.printf("%.0f",x+(n-3*x)/5);
		}

	}

}
