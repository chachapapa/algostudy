package class1;

import java.util.Scanner;

public class alphabet {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
		char[] arr = sc.next().toCharArray();
		
		int[] arr2 = new int[26];
		
		for(int i = 0 ; i<arr2.length ; i++) {
			arr2[i] = -1;
		}
		
		for(int i = arr.length-1 ; i>=0 ; i--) {
			arr2[arr[i]-'a'] = i;
		}
 		
		for(int i = 0 ; i<arr2.length ; i++) {
			System.out.print(arr2[i]+" ");
		}
	}

}
