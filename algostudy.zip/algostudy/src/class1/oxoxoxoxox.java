package class1;

import java.util.Scanner;

public class oxoxoxoxox {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int t = sc.nextInt();
		for (int test = 1; test <= t; test++) {

			String[] arr = sc.next().split("");

			int count = 0;
			int sum = 0;
			int idx = 0;
			for (int i = 0; i < arr.length; i++) {
				if(arr[i].equals("O")) {
				count ++;
				sum+=count;
				}else {
					count = 0;
				}
			}
			System.out.println(sum);
		}

	}

}
