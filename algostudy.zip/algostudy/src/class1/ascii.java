package class1;

import java.util.Scanner;

public class ascii {

	public static void main(String[] args) {

		
		Scanner sc = new Scanner(System.in);
		
		char x = sc.next().charAt(0);
		
		System.out.println((int)x);
		
	}

}
