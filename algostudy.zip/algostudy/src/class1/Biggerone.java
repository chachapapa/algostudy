package class1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Biggerone {

	public static void main(String[] args) {

		
		Scanner sc = new Scanner(System.in);
		
		int x = sc.nextInt();
		int y = sc.nextInt();
		
		List<Integer> xx = new ArrayList<>();
		List<Integer> yy = new ArrayList<>();
		
		while(x>0) {
			xx.add(x%10);
			x /= 10;
		}
		
		while(y>0) {
			yy.add(y%10);
			y /= 10;
		}
		
		int a = 0;
		int b = 0;
		
		for(int i = 0 ; i<xx.size() ; i++) {
			a += xx.get(i)*Math.pow(10, xx.size()-(i+1));
		}
		
		for(int i = 0 ; i<yy.size() ; i++) {
			b += yy.get(i)*Math.pow(10, yy.size()-(i+1));
		}
		
		if(a > b) {
			System.out.println(a);
		}else {
			System.out.println(b);
		}
	}

}
