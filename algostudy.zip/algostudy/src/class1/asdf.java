package class1;

import java.util.Scanner;

public class asdf {

	public static void main(String[] args) {
		
		
		Scanner sc= new Scanner(System.in);
		
		int n = sc.nextInt();
		int x = sc.nextInt();
		
		System.out.println(n+x);
	}

}
