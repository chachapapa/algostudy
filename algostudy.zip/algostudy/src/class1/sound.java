package class1;

import java.util.Scanner;

public class sound {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int[] arr = new int[8];

		for (int i = 0; i < 8; i++) {
			arr[i] = sc.nextInt();

		}

		loop : for (int noo = 0;;) {
			int res = 0;
			for (int i = 0; i < 8; i++) {
				if (arr[i] != i + 1) {
					res++;
				}
			}

			if (res == 0) {
				System.out.println("ascending");
				break loop;
			}

			res = 0;
			for (int i = 0; i < 8; i++) {
				if (arr[i] != 8 - i) {
					res++;
				}
			}

			if (res == 0) {
				System.out.println("descending");
			}else {
				System.out.println("mixed");
			}
			
			break;
			
			
			
		}
	}

}
