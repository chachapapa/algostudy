package math;

import java.util.Scanner;

public class tile {
	private static long dp[]; 
	private static long sym[];

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int n = scanner.nextInt();
		//1<= N <= 30 이라서 최대갯수대입
		dp = new long[31];
		sym = new long[31];
		
		
		System.out.println(tile_code(n));
	}
	private static long tile_code(int n) {
		return (tile(n)-symmetry(n))/2 + symmetry(n);
	}
	//모든 타일의경우
	private static long tile(int n) {
		if(dp[n] != 0)
			return dp[n];
		if(n == 1)
			return dp[1] = 1;
		if(n == 2)
			return dp[2] = 3;
		
		//dp[n] = ~~~~ - symmetry[n] 이 점화식은
		//전체타일경우의수 - 중복되는타일경우의수 이다.
		dp[n] = tile(n-1) + 2*tile(n-2);
		
		
		return dp[n];
	}
	//좌우대칭인경우
	private static long symmetry(int n) {
		if(sym[n] != 0)
			return sym[n];
		if(n == 1) 
			return sym[1] = 1;
		if(n == 2)
			return sym[2] = 3;
		if(n == 3)
			return sym[3] = 1;
		if(n == 4)
			return sym[4] = 5; 
		
		return sym[n] = symmetry(n-2) + 2*symmetry(n-4);
	}

}