package shortestRoute;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

public class shortestroute1 {
	
	
	//노드 클래스 생성, 우선순위큐 쓰기위해 비교함수 정의해주기.
	static class Node implements Comparable<Node> {
		int end;
		int weight;

		public Node(int end, int weight) {
			super();
			this.end = end;
			this.weight = weight;
		}

		@Override
		public int compareTo(Node o) {
			return Integer.compare(this.weight, o.weight);
		}

		@Override
		public String toString() {
			return "Node [end=" + end + ", weight=" + weight + "]";
		}
		
	}
	
	static int v;
	static int e;
	static int start;
	
	//노드를 데이터타입으로 가지는  리스트를 데이터타입으로 가지는 배열 생성.
	//즉 제일 바깥 범위에서 리스트를 정의하면 리스트가 아닌 배열.
	
	//List<List<Node>> list
	//이거는 노드를 데이터 타입으로 가지는 리스트를 데이터타입으로 가지는 리스트 생성.
	//제일 바깥범위에서 정의시 리스트.
	
	static List<Node>[] list;
	static int[] res;
	static PriorityQueue<Node> pq;
//	static boolean[] visited;
	//visited배열이 필요가 없다..?

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		//정점, 간선 수, 시작 노드
		v = sc.nextInt();

		e = sc.nextInt();

		start = sc.nextInt();
		
		
		//인접노드배열 생성.
		list = new ArrayList[v + 1];
		
		//배열 내부 칸마다 리스트 생성해주기.
		for (int i = 0; i < v + 1; i++) {
			list[i] = new ArrayList<>();
		}
		
		//각 인덱스를 노드번호로 가지는 노드의 인접노드+가중치 넣어주기.
		for (int i = 0; i < e; i++) {
			list[sc.nextInt()].add(new Node(sc.nextInt(), sc.nextInt()));
		}
		
		//최단거리를 넣어줄 res 배열 생성.
		res = new int[v + 1];
		
		//크기비교를 위해 기본값을 최댓값으로 모두 변경.
		for (int i = 0; i < v + 1; i++) {
			res[i] = Integer.MAX_VALUE;
		}
		
		//이미 최단거리를 찾아둔 지점 중 최솟값을 가지고 있는 노드를 뽑아내기 위한 프라이어리티큐.
		pq = new PriorityQueue<Node>();
		stra(start);

		for (int i = 1; i < v + 1; i++) {
			if (res[i] != Integer.MAX_VALUE) {
				System.out.println(res[i]);
			} else {
				System.out.println("INF");
			}
		}
	}

	public static void stra(int start) {
		
		//뽑아낼때 방문처리하기 위한 visited 배열...이었는데
		//visited 다 지우거 제출해도 맞다.
		//필요가 없음. 왜그렇지.
//		visited = new boolean[v + 1];
		//넣으려는 가중치가  기존 최소 가중치보다 낮을 때만 pq에 넣어준다는 조건이 visited의 역할을 완전히 대체하고 있음.
		
		//시작지점과 시작 거리 0 을 먼저 넣어주기.
		//pq에 값을 넣어줄 때 마다 integer.maxvalue로 초기화해줬던 res배열에 현재 거리값 넣어주기
		
		pq.add(new Node(start, 0));
		res[start] = 0;

		while (!pq.isEmpty()) {
			//뽑으면 현재 pq내부에 있는 경우의 수들 중에서 가중치가 가장 낮은 값이 튀어나옴.
			Node now = pq.poll();
			//뽑은 값의 위치에서 연결되어 있는 모든 노드에 대해
			for (int i = 0; i < list[now.end].size(); i++) {
				//res에 저장되어 있는 해당 노드로 가는데에 현재까지의 최소 비용 과 비교, 더 작으면 교체, pq에 해당 값을 넣어줌.
				if ( res[list[now.end].get(i).end] > now.weight + list[now.end].get(i).weight) {
					pq.add(new Node(list[now.end].get(i).end, now.weight + list[now.end].get(i).weight));
					res[list[now.end].get(i).end] = now.weight + list[now.end].get(i).weight;
				}

			}
			
//			System.out.println(Arrays.toString(res));
		}

	}

}
