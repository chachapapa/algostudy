package shortestRoute;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;


public class floid {
	
	static class Node implements Comparable<Node>{
		int to;
		int length;
		
		
		public Node(int to, int length) {
			this.to = to;
			this.length = length;
		}


		@Override
		public int compareTo(Node o) {
			return Integer.compare(this.length, o.length);
		}
	}
	
	
	static int n;
	static int m;
	static List<List<Node>> list;
	static int[] res;
	static boolean[] visited;
	static PriorityQueue<Node> pq;
	

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		n = sc.nextInt();
		m = sc.nextInt();
		
		
		
		list = new ArrayList<>();
		
		for(int i = 0 ; i< n+1 ; i++) {
			list.add(new ArrayList<>());
		}
		
		for(int i = 0 ; i < m ; i++) {
			
			list.get(sc.nextInt()).add(new Node(sc.nextInt(), sc.nextInt()));
		}
		res = new int[n+1];		
		StringBuilder sb = new StringBuilder();
		for(int start = 1 ; start<n+1 ; start++) {
			
			for(int i = 0 ; i< n+1 ; i++) {
				res[i] = Integer.MAX_VALUE;
			}
			
			
			visited = new boolean[n+1];
			pq = new PriorityQueue<>();
			stra(start);
			
			
			for(int i = 1 ; i< n+1 ; i++) {
				
				if(res[i] != Integer.MAX_VALUE) {
				sb.append(res[i]+" ");
				}else {
					sb.append(0+" ");
				}
			}
			sb.append("\n");
			
			
		}
		System.out.println(sb);
	}
	
	public static void stra(int start) {
		pq.add(new Node(start, 0));
		res[start] = 0;
		
		
		while(!pq.isEmpty()) {
			
			Node now = pq.poll();
			visited[now.to] = true;
			for(int i = 0 ; i< list.get(now.to).size() ; i++) {
				if(visited[list.get(now.to).get(i).to] == false && now.length+list.get(now.to).get(i).length < res[list.get(now.to).get(i).to]) {
					res[list.get(now.to).get(i).to] = now.length+list.get(now.to).get(i).length;
					pq.add(new Node(list.get(now.to).get(i).to, now.length+list.get(now.to).get(i).length));
				}
			}
			
		}
		
		
		
	}
}
