package IM;

import java.util.Arrays;
import java.util.Scanner;

public class safeguard {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int m = sc.nextInt() + 1;
		int n = sc.nextInt() + 1;

		int[][] land = new int[n][m];

		int store = sc.nextInt() + 1;

		int[][] place = new int[store][2];

		int mex = 0;
		int mey = 0;

		for (int i = 0; i < store; i++) {
			place[i][0] = sc.nextInt();
			place[i][1] = sc.nextInt();
		}

		for (int i = 0; i < store; i++) {
			if (place[i][0] == 1) {
				place[i][0] = 0;

			} else if (place[i][0] == 2) {
				place[i][0] = n - 1;
			} else if (place[i][0] == 3) {
				place[i][0] = place[i][1];
				place[i][1] = 0;
			} else {
				place[i][0] = place[i][1];
				place[i][1] = m - 1;
			}

			if (i == store - 1) {
//					System.out.println(i);
				mex = place[i][0];
				mey = place[i][1];
			}
		}
//		for(int i = 0 ; i<store ; i++) {
//			System.out.println(Arrays.toString(place[i]));
//		}
//		System.out.println(mex);
//		System.out.println(mey);

		int sum = 0;

		for (int i = 0; i < store - 1; i++) {
			
			sum += Math.abs(place[i][0] - mex) + Math.abs(place[i][1] - mey);

			if (Math.abs(place[i][0] - mex) == n - 1 && place[i][1] <= m / 2) {
				sum += place[i][1] + mey - Math.abs(place[i][1] - mey);
			} else if (Math.abs(place[i][1] - mey) == m - 1 && place[i][0] <= n / 2) {
				sum += place[i][0] + mex - Math.abs(place[i][0] - mex);
			} else if (Math.abs(place[i][0] - mex) == n - 1 && place[i][1] > m / 2) {
				sum += (m - 1 - place[i][1]) + (m - 1 - mey) - Math.abs(place[i][1] - mey);
			} else {
				sum += (n - 1 - place[i][0]) + (n - 1 - mex) - Math.abs(place[i][0] - mex);
			}

		}

		System.out.println(sum);

	}

}
