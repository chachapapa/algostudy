package IM;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class alphabet {

	static String[] arr;
	static boolean[] yesno;
	static int[] count;
	static int res;
	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int t = sc.nextInt();

		for (int test = 1; test <= t; test++) {

			int n = sc.nextInt();
			yesno = new boolean[n];
			arr = new String[n];
			count = new int[26];
			for (int i = 0; i < n; i++) {
				arr[i] = sc.next();
			}
			
			List<String> list = new ArrayList<>();
			booboonjibhab(list , 0);
			
			System.out.println(res);
		}
	}

	public static void booboonjibhab(List<String> list, int x) {
//		System.out.println(arr.length);
//		System.out.println(x);
		if (x == arr.length-1) {
			list = new ArrayList<>();
			count = new int[26];
			System.out.println("마지막에 오긴 온다");
			for (int i = 0; i < arr.length; i++) {
				if (yesno[i]) {
					list.add(arr[i]);
				}
			}
			
			System.out.println(list);
			
			
			for(int i = 0; i<list.size() ; i++) {
				char[] countgogo = list.get(i).toCharArray();
				for(int j = 0; j<countgogo.length ; j++) {
					count[(int)(countgogo[j]-'a')]++;
				}
			}
			
			System.out.println(Arrays.toString(count));
			
			int countzero = 0;
			for(int i = 0 ; i<count.length ; i++) {
				if(count[i] == 0) {
					countzero++;
				}
			}
			
			if(countzero == 0) {
				res++;
			}
		}
		
		if (x + 1 <= arr.length) {
//			System.out.println(x);
//			System.out.println("재귀도 불러지고");
//			System.out.println(Arrays.toString(yesno));
			yesno[x] = true;
			booboonjibhab(list, x + 1);
			yesno[x] = false;
			booboonjibhab(list, x + 1);
		}

	}
}
