package IM;

import java.util.Arrays;
import java.util.Scanner;

public class dohwaji {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();

		int[][] arr = new int[100][100];

		int[][] black = new int[n][2];

		for (int i = 0; i < n; i++) {
			black[i][0] = sc.nextInt();
			black[i][1] = sc.nextInt();
		}
		
		
		for(int i = 0 ; i < n ; i++) {
			for(int x = black[i][0] ; x< black[i][0]+10 ; x++ ) {
				for(int y = black[i][1] ; y<black[i][1]+10 ; y++) {
					arr[x][y] = 1;
				}
			}
		}
		
		
		int sum = 0;
		for(int i = 0; i<100 ; i++ ) {
			for(int j = 0; j<100 ; j++) {
				sum += arr[i][j];
			}
		}
		
		System.out.println(sum);
	}

}
