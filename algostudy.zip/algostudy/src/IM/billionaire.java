package IM;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class billionaire {

	public static void main(String[] args) throws FileNotFoundException {

		// 연속 n일의 매매가 암
		// 최대 하루 1 만큼 구입
		// 판매는 언제든

		Scanner sc = new Scanner(System.in);

		int t = sc.nextInt();
		for (int test = 1; test <= t; test++) {

			// n은 100만 이하 시세 측정일 갯수
			int n = sc.nextInt();
			long[] arr = new long[n];
			for (int i = 0; i < n; i++) {
				arr[i] = sc.nextLong();
			}
//			System.out.println(Arrays.toString(arr));

			long revenue = 0;
			int tmp = 0;
			loop: for (int i = arr.length - 1; i > 0; i = tmp) {
				for (int j = i - 1; j >= 0; j--) {
					if (arr[j] < arr[i]) {
						revenue += arr[i] - arr[j];
						
					} else {
						tmp = j;
						break;
						
					}

					if (j == 0) {
						break loop;
					}
				}

			}

			System.out.println("#"+test+" "+revenue);

		}
	}

}
