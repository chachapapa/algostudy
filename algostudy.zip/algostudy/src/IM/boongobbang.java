package IM;

import java.util.Arrays;
import java.util.Scanner;

public class boongobbang {

	public static void main(String[] args) {

		
		
		Scanner sc = new Scanner(System.in);
		
		int t = sc.nextInt();
		
		for(int test = 1 ; test<=t ; test++) {
			
			
			//n명
			//m초 k개
			//모든손님에게 기다리는시간 없이 붕어빵제공
			int n = sc.nextInt();
			int m = sc.nextInt();
			int k = sc.nextInt();
			
			int[] arrival = new int[n];
			for(int i = 0 ; i < n ; i++) {
				arrival[i] = sc.nextInt();
			}
			Arrays.sort(arrival);
			int[] count = new int[11112];
			
			for(int i = 0 ; i<count.length ; i++) {
				if(i>0 && i%m == 0) {
				count[i] = k; 
				}
			}

			
			for(int i = 1 ; i<count.length ; i++) {
				count[i] = count[i]+count[i-1]; 
			}
			
			

			System.out.print("#"+test+" ");
			
			int res = 1;
			for(int i = 0 ; i<arrival.length ; i++) {
				if(count[arrival[i]] <= 0) {
					System.out.println("Impossible");
					res = 0;
					break;
				}
				for(int x = arrival[i] ; x<count.length ; x++) {
					count[x]--;	
				}
				

			}
			
			if(res == 1) {
				System.out.println("Possible");
			}
			
		}
		
		
		
	}

}
