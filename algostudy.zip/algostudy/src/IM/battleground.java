package IM;

import java.util.Arrays;
import java.util.Scanner;

public class battleground {
	public static void main(String[] args) {

		// . 평지
		// * 벽돌벽
		// # 강철벽
		// - 물
		// ^ 위쪽바라보는 전차
		// v 아래쪽바라보는 전차
		// < 왼쪽
		// > 오른쪽

		// u d l r shoot

		Scanner sc = new Scanner(System.in);

		int t = sc.nextInt();

		for (int test = 1; test <= t; test++) {

			int h = sc.nextInt();
			int w = sc.nextInt();

			String[][] ground = new String[h + 2][w + 2];

			for (int x = 1; x < h + 1; x++) {
				String[] tmp = sc.next().split("");
				for (int y = 1; y < w + 1; y++) {
					ground[x][y] = tmp[y - 1];
				}

			}

			int command = sc.nextInt();
			String[] cmd = new String[command];
			cmd = sc.next().split("");
			//System.out.println(Arrays.toString(cmd));

			// 현재 탱크 위치
			int tankx = 0;
			int tanky = 0;
			for (int x = 1; x < h + 1; x++) {
				for (int y = 1; y < w + 1; y++) {
					if (ground[x][y].equals("^") || ground[x][y].equals("v") || ground[x][y].equals("<")
							|| ground[x][y].equals(">")) {
						tankx = x;
						tanky = y;
					}

				}
			}

			for (int i = 0; i < cmd.length; i++) {
				//System.out.println(cmd[i]);
				if (cmd[i].equals("S")) {

					switch (ground[tankx][tanky]) {

					case "^":
						for (int x = tankx - 1; x >= 1; x--) {
							if (ground[x][tanky].equals("*")) {
								ground[x][tanky] = ".";
								break;
							} else if (ground[x][tanky].equals("#")) {
								break;
							}
						}
						break;
					case "v":
						for (int x = tankx + 1; x < h + 1; x++) {
							if (ground[x][tanky].equals("*")) {
								ground[x][tanky] = ".";
								break;
							} else if (ground[x][tanky].equals("#")) {
								break;
							}
						}
						break;
					case "<":
						for (int y = tanky - 1; y >= 1; y--) {
							if (ground[tankx][y].equals("*")) {
								ground[tankx][y] = ".";
								break;
							} else if (ground[tankx][y].equals("#")) {
								break;
							}
						}
						break;
					case ">":
						for (int y = tanky + 1; y < w + 1; y++) {
							if (ground[tankx][y].equals("*")) {
								ground[tankx][y] = ".";
								break;
							} else if (ground[tankx][y].equals("#")) {
								break;
							}
						}

					}

				} else if (cmd[i].equals("U")) {
					ground[tankx][tanky] = "^";
					if (ground[tankx - 1][tanky] != null && ground[tankx - 1][tanky].equals(".")) {
						ground[tankx - 1][tanky] = "^";
						ground[tankx][tanky] = ".";
						tankx--;
					}

				} else if (cmd[i].equals("D")) {
					ground[tankx][tanky] = "v";
					if (ground[tankx + 1][tanky] != null && ground[tankx + 1][tanky].equals(".")) {
						ground[tankx + 1][tanky] = "v";
						ground[tankx][tanky] = ".";
						tankx++;
					}

				} else if (cmd[i].equals("L")) {
					ground[tankx][tanky] = "<";

					if (ground[tankx][tanky - 1] != null && ground[tankx][tanky - 1].equals(".")) {
						ground[tankx][tanky - 1] = "<";
						ground[tankx][tanky] = ".";
						tanky--;
					}
				} else if (cmd[i].equals("R")) {
					ground[tankx][tanky] = ">";

					if (ground[tankx][tanky + 1] != null && ground[tankx][tanky + 1].equals(".")) {
						ground[tankx][tanky + 1] = ">";
						ground[tankx][tanky] = ".";
						tanky++;
					}
				}

				/*for (int x = 1; x < h + 1; x++) {
					System.out.println(Arrays.toString(ground[x]));
				}
				System.out.println();*/
			}
			System.out.print("#"+test+" ");
			for (int x = 1; x < h + 1; x++) {
				for (int y = 1; y < w + 1; y++) {
					System.out.print(ground[x][y]);
				}
				System.out.println();
			}
		}
	}
}
