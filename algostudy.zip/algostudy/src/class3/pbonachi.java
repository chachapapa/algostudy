package class3;

import java.util.Scanner;

public class pbonachi {

	public static void main(String[] args) {
		
		
		
		Scanner sc = new Scanner(System.in);
		
		int t  = sc.nextInt();
		
		for(int test = 1 ; test <= t ; test++) {
			
			int n = sc.nextInt();
			
			int[] arrzero = new int[n+1];
			int[] arrone = new int[n+1];
			
			if(n >= 1) {
			arrzero[0] = 1;
			arrzero[1] = 0;
			arrone[0] = 0;
			arrone[1] = 1;
			}else {
				arrzero[0] = 1;
				arrone[0] = 0;
			}
			
			for(int i = 2; i<n+1 ; i++) {
				arrzero[i] = arrzero[i-1]+arrzero[i-2];
				arrone[i] = arrone[i-1] + arrone[i-2];
			}
			
			System.out.println(arrzero[n]+" "+arrone[n]);
		}
		
		
	}

}
