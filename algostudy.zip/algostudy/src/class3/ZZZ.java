package class3;

import java.util.Scanner;

public class ZZZ {
	
	static int n;
	static int r;
	static int c;
	static int size;
	static int count = 0;
	
	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
		
		n = sc.nextInt();
		
		r= sc.nextInt();
		c= sc.nextInt();
		size = (int) Math.pow(2,n);
		
		zzz(size, r, c );
		System.out.println(count);
		
	}
	
	
	public static void zzz(int size,int x , int y) {
		if(size == 1)
			return;
		
		if(x < size/2 && y < size/2) {
			zzz(size/2, x, y);
		}
		else if(x < size/2 && y >= size/2) {
			count += size * size / 4;
			zzz(size/2, x, y - size/2);
		}
		else if(x >= size/2 && y < size/2) {
			count += (size * size / 4) * 2;
			zzz(size/2, x - size/2, y);
		}
		else {
			count += (size * size / 4) * 3;
			zzz(size/2, x - size/2, y - size/2);
		}
		
		
		
//		if(number%4 == 1) {
//			zzz(x+1,y-1,number+1);
//			return;
//		}
//		
//		
//		
//		if(number%8 == 3) {
//			zzz(x-1,y+1,number+1);
//			return;
//		}
//		if(number%16 == 7) {
//			zzz(x+1, y-3, number+1);
//			return;
//		}
//		if(number%32 == 15) {
//			zzz(x-3,y+1,number+1);
//			return;
//		}
//		
//		if(number%128 == 31) {
//			zzz(x+1,y-7,number+1);
//			return;
//		}
		
		
	}
}
