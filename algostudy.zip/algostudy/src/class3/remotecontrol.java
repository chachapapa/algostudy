package class3;

import java.util.Arrays;
import java.util.Scanner;

public class remotecontrol {
	static String goal2;
	static boolean[] remote;
	static int channel;
	static int goal;
	static int min;
	static int move;

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		goal = sc.nextInt();
		goal2 = String.valueOf(goal);

		int n = sc.nextInt();

		remote = new boolean[10];

		for (int i = 0; i < n; i++) {
			remote[sc.nextInt()] = true;
		}

		min = 500000;
		move = 0;
		channel = 100;

		boom(0);
//		System.out.println(move);
		
		if(Math.abs(goal-100) < min) {
			System.out.println(Math.abs(goal-100));
		}else {
			System.out.println(min);
		}
		
	}

	public static void boom(int button) {

		if (button == goal2.length()-1 ||button == goal2.length() || button==goal2.length()+1) {
//			System.out.println("채널 후보"+channel);
//			System.out.println("목표값이랑차이 최소값" +min);
			if (Math.abs(goal - channel)+button < min) {
//				System.out.println("min값 변경!");
				min = Math.abs(goal - channel)+button;
				move = channel;
			}
			
			if(button==goal2.length()+1) {
			return;
			}
		}
			
		if(button == 0) {
				channel = 0;
		}
		for (int i = 0; i < remote.length; i++) {
			if (remote[i] == false) {
				channel += i * Math.pow(10, button);
				boom(button + 1);
				channel -= i * Math.pow(10, button);
			}
		}
	}

}
