package greedy;

import java.util.Arrays;
import java.util.Scanner;

public class redbull {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		double[] arr =new double[n];
		
		for(int i = 0 ; i<n ; i++) {
			arr[i] = sc.nextDouble();
		}
		
		Arrays.sort(arr);
		
		double res = arr[n-1];
		
		for(int i = 0 ; i<n-1  ; i++) {
			res += arr[i]/2;
		}
		
		if(res%1 == 0) {
		System.out.printf("%.0f",res);
		}else {
			System.out.println(res);
		}
	}

}
